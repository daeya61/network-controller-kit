package com.mommoo.customview;

/**
 * Created by mommoo on 2016-04-22.
 */
public interface OnOffClickListener{
    void onClick();
}
