package com.mommoo.customview;

/**
 * Created by mommoo on 2016-04-14.
 */
public interface MouseEvent {
    void onMove(String mousePoint);
}
