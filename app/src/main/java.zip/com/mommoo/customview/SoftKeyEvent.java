package com.mommoo.customview;

/**
 * Created by mommoo on 2016-04-14.
 */
public interface SoftKeyEvent{
    public void onClick(String keyValue);
}
