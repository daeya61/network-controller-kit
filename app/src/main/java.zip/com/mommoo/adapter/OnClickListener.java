package com.mommoo.adapter;

/**
 * Created by mommoo on 2016-04-07.
 */
public interface OnClickListener {
    public void onClick(int position);
}
