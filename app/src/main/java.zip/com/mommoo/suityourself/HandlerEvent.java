package com.mommoo.suityourself;

/**
 * Created by mommoo on 2016-04-07.
 */
public interface HandlerEvent {
    public void event();
}
